let show = document.querySelector(".showPassword");
let passwordInput = document.querySelector(".password input");

show.addEventListener('click', showPassword);
function showPassword() {
    if(show.innerText==="Show") {
        show.innerText="hide";
        passwordInput.type="text"
    }else{
        show.innerText="show";
        passwordInput.type="password"
    }
    
}